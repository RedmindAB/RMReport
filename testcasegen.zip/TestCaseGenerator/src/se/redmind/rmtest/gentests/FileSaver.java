package se.redmind.rmtest.gentests;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileSaver {

	
	public void SaveFile(String filename, String content) throws IOException{
		FileOutputStream out = new FileOutputStream(System.getProperty("user.dir")+"/reports/"+filename);
		out.write(content.getBytes());
		out.close();
	}
	
}
