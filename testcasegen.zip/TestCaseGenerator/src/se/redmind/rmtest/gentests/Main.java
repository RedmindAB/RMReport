package se.redmind.rmtest.gentests;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws Exception {
		String date = "20150204-";
		Time time = new Time();
		String suitename = "GeneratedSuite";
		FileSaver fileSaver = new FileSaver();
		for (int i = 0; i < 500; i++) {
			String timestamp = date+time.getTime();
			String report = new Suite().runSuite(suitename, timestamp, 200);
			String filename = "TEST-test.java.se.redmind.rmtest.selenium.example."+suitename+"-"+timestamp+".xml";
//			System.out.println(report);
			System.out.println(i+1);
			fileSaver.SaveFile(filename, report);
		}

	}

}
