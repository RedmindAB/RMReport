package se.redmind.rmtest.gentests;

import java.io.IOException;

public class Suite {
	
	public Suite() {
		// TODO Auto-generated constructor stub
	}
	
	public String runSuite(String suitename, String timestamp, int nrOfTestCases) throws IOException{
		Time time = new Time();
		String filename = "TEST-test.java.se.redmind.rmtest.selenium.example."+suitename+"-"+timestamp+".xml";
		String tests1;
		GenerateTestcase generateTestcase = new GenerateTestcase("RandomClass", timestamp, nrOfTestCases);
		tests1 = generateTestcase.getTestcaseResult();
		String tests2;
		GenerateTestcase generateTestcase2 = new GenerateTestcase("RandomSuperClass", timestamp, nrOfTestCases);
		tests2 = generateTestcase2.getTestcaseResult();
		Core beginning = new Core(getTotalTime(generateTestcase, generateTestcase2), getTotalTests(generateTestcase, generateTestcase2), 0, 0, getTotalFails(generateTestcase, generateTestcase2), timestamp, suitename);
		String beg = beginning.getBeginning();
		String end = beginning.getEnd();
		return beg+tests1+tests2+end;
	}
	
	private float getTotalTime(GenerateTestcase... testcase){
		float f = 0f;
		for (GenerateTestcase generateTestcase : testcase) {
			f+= generateTestcase.getTotalTime();
		}
		return f;
	}
	
	private int getTotalTests(GenerateTestcase... testcase){
		int tests = 0;
		for (GenerateTestcase generateTestcase : testcase) {
			tests+= generateTestcase.getTests();
		}
		return tests;
	}
	
	private int getTotalFails(GenerateTestcase... testcase){
		int fails = 0;
		for (GenerateTestcase generateTestcase : testcase) {
			fails+= generateTestcase.getFailures();
		}
		return fails;
	}
	
	
}
