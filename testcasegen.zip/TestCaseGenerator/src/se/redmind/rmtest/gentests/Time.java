package se.redmind.rmtest.gentests;

public class Time {

	int hours=0;
	int mins=0;
	int secs=0;
	
	public String getTime(){
		String time = "";
		if (hours>24) {
			hours = 0;
		}
		time+=convertToString(hours);
		hours++;
		if (mins>60) {
			mins = 0;
		}
		time+=convertToString(mins);
		mins++;
		if (secs > 60) {
			secs = 0;
		}
		time+=convertToString(secs);
		secs++;
		return time;
	}
	
	public String convertToString(int unit){
		if (unit < 10) {
			return ""+0+unit;
		}
		return ""+unit;
	}
	
	
}
