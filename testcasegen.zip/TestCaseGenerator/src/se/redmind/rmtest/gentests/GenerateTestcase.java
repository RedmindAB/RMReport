package se.redmind.rmtest.gentests;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GenerateTestcase {
	
	List<String> driverArray;
	Random ran;
	String timestamp;
	int limit = 10;
	String classname;
	int nrOfTest;
	int i = 1;
	
	float totalTime;
	int tests;
	int failures;
	
	public GenerateTestcase(String className, String timestamp, int nrOfTests) {
		driverArray = generateDrivers();
		this.classname = className;
		ran = new Random();
		this.nrOfTest = nrOfTests;
		this.timestamp = timestamp;
	}
	
	private List<String> generateDrivers(){
		List<String> drivers = new ArrayList<String>();
		drivers.add("OSX chrome");
		drivers.add("OSX firefox");
		drivers.add("OSX safari");
		drivers.add("OSX opera");
		drivers.add("htc HTC ONE 4.4.3");
		drivers.add("iPhone 5s 8.1");
		return drivers;
	}
	
	
	public String getTestcaseResult(){
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < nrOfTest; i++) {
			int id = getId();
			for (String driver : driverArray) {
				sb.append(generateTest(driver, id));
				sb.append("\n");
			}
		}
		return sb.toString();
	}
	
	private String generateTest(String driver, int id){
		boolean passed = ran.nextInt(100) > limit;
		String testcase = "";
		tests++;
		if (passed) {
			testcase = "<testcase name=\"random"+id+"["+driver+"]\" classname=\"se.redmind.rmtest.selenium.example."+classname+"("+timestamp+")\" time=\""+getRandomTime()+"\"/>";
		}
		else{
			failures++;
			testcase = "<testcase name=\"random"+id+"["+driver+"]\" classname=\"se.redmind.rmtest.selenium.example."+classname+"("+timestamp+")\" time=\""+getRandomTime()+"\">"
			+ "\n\t<failure type=\"java.lang.AssertionError:\">java.lang.AssertionError: null"
			+ "\n\t\tat org.junit.Assert.fail(Assert.java:86)"
			+ "\n\t\tat org.junit.Assert.assertTrue(Assert.java:41)"
			+ "\n\t\tat org.junit.Assert.assertTrue(Assert.java:52)"
			+ "\n\t\tat se.redmind.rmtest.selenium.example.CreateRandomRes3.random14(CreateRandomRes3.java:128)"
			+ "\n\t</failure>"
			+ "</testcase>";	
		}
		return testcase;
	}

	protected float getRandomTime() {
		float f = ran.nextFloat()*2;
		totalTime+=f;
		return f;
	}
	
	private int getId(){
		return i++;
	}

	public float getTotalTime() {
		return totalTime;
	}

	public void setTotalTime(float totalTime) {
		this.totalTime = totalTime;
	}

	public int getTests() {
		return tests;
	}

	public void setTests(int tests) {
		this.tests = tests;
	}

	public int getFailures() {
		return failures;
	}

	public void setFailures(int failures) {
		this.failures = failures;
	}

}
