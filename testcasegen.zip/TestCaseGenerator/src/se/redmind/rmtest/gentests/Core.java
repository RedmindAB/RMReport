package se.redmind.rmtest.gentests;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class Core {
	
	public static String beginning;
	private String timestamp;
	private int failures;
	private int skipped;
	private int errors;
	private int tests;
	private float time;
	private String suitename;
	
	public Core(float time, int tests, int errors, int skipped, int failures, String timestamp, String suitename) throws IOException {
		this.time = time;
		this.tests = tests;
		this.errors = errors;
		this.skipped = skipped;
		this.failures = failures;
		this.timestamp = timestamp;
		this.suitename = suitename;
		beginning = getBeginning();
	}
			
	public String getBeginning() throws IOException{
		String path = System.getProperty("user.dir")+"/beg.txt";
		File file = new File(path);
		String s = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<testsuite name=\"test.java.se.redmind.rmtest.selenium.example."+suitename+"("+timestamp+")\" time=\""+time+"\" tests=\""+tests+"\" errors=\""+errors+"\" skipped=\""+skipped+"\" failures=\""+failures+"\">";
		String sFile = new String(Files.readAllBytes(file.toPath()));
		return s+sFile;
	}
	
	public String getEnd(){
		return "</testsuite>";
	}
}
